document.querySelector('form').addEventListener('submit', function(e) {
  e.preventDefault();
  alert('Formulario enviado correctamente');
});


function redirigirProducto() {
  window.location.href = "https://www.tusitio.com/productos";
}

function redirigirProducto() {
  window.location.href = "https://www.tusitio.com/productos";
}